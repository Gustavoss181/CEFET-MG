typedef struct{
	char nome[50];
	int ano;
	unsigned int cpf;
}Pessoa;

void Preencher(pessoa);
void MaisVelho(pessoa);
void MaisNovo(pessoa);
void Nomes(pessoa);
void Maiores(pessoa);
void CpfImpar(pessoa);
void OrdenarIdade(pessoa);
