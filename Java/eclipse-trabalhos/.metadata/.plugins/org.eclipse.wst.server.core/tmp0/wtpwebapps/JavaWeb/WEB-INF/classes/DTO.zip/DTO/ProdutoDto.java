package DTO;

public class ProdutoDto {
	private int idProduto;
	private String nomeProduto;
	private int idFornecedor;
	private int idCategoria;
	private String quantidadePorUnidade;
	private double precoUnitario;
	private int unidadesEmEstoque;
	private int unidadesEmOrdem;
	private int nivelDeReposicao;
	private boolean descontinuado;
	
	public int getIdProduto() {
		return idProduto;
	}
	public void setIdProduto(int idProduto) {
		this.idProduto = idProduto;
	}
	public String getNomeProduto() {
		return nomeProduto;
	}
	public void setNomeProduto(String nomeProduto) {
		this.nomeProduto = nomeProduto;
	}
	public int getIdFornecedor() {
		return idFornecedor;
	}
	public void setIdFornecedor(int idFornecedor) {
		this.idFornecedor = idFornecedor;
	}
	public int getIdCategoria() {
		return idCategoria;
	}
	public void setIdCategoria(int idCategoria) {
		this.idCategoria = idCategoria;
	}
	public String getQuantidadePorUnidade() {
		return quantidadePorUnidade;
	}
	public void setQuantidadePorUnidade(String quantidadePorUnidade) {
		this.quantidadePorUnidade = quantidadePorUnidade;
	}
	public double getPrecoUnitario() {
		return precoUnitario;
	}
	public void setPrecoUnitario(double precoUnitario) {
		this.precoUnitario = precoUnitario;
	}
	public int getUnidadesEmEstoque() {
		return unidadesEmEstoque;
	}
	public void setUnidadesEmEstoque(int unidadesEmEstoque) {
		this.unidadesEmEstoque = unidadesEmEstoque;
	}
	public int getUnidadesEmOrdem() {
		return unidadesEmOrdem;
	}
	public void setUnidadesEmOrdem(int unidadesEmOrdem) {
		this.unidadesEmOrdem = unidadesEmOrdem;
	}
	public int getNivelDeReposicao() {
		return nivelDeReposicao;
	}
	public void setNivelDeReposicao(int nivelDeReposicao) {
		this.nivelDeReposicao = nivelDeReposicao;
	}
	public boolean isDescontinuado() {
		return descontinuado;
	}
	public void setDescontinuado(boolean descontinuado) {
		this.descontinuado = descontinuado;
	}
}
