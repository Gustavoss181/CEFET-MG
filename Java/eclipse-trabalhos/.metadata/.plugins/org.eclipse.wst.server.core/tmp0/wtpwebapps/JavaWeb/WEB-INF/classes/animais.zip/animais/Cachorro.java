package animais;

public class Cachorro extends Animal {
	
	private int unha;

	public Cachorro(float tamanho, String nome, int unha) {
		super(tamanho, nome);
		this.unha = unha;
	}

	public Cachorro() {
		
	}
	
	public int getUnhas() {
		return this.unha;
	}
	
	@Override
	public String falar() {
		return "auauauauau";
	}
	@Override
	public String andar() {
		return getNome() + " andando...";
	}
	
	public void morder() {
		System.out.println("Nhac");
	}

}
