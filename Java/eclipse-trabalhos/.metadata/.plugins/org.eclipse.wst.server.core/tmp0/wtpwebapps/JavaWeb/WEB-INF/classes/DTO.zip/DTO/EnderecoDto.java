package DTO;

public class EnderecoDto {

}
