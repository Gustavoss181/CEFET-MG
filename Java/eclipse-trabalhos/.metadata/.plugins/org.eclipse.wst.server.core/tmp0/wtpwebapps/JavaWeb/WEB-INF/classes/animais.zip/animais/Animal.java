package animais;

public abstract class Animal {
	private float tamanho;
	private String nome;
	
	public Animal(float tamanho, String nome) {
		super();
		this.tamanho = tamanho;
		this.nome = nome;
	}
	
	public Animal() {
		super();
	}

	public float getTamanho() {
		return tamanho;
	}

	public void setTamanho(float tamanho) {
		this.tamanho = tamanho;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}
	
	public abstract String falar();
	
	public abstract String andar();
	
}
