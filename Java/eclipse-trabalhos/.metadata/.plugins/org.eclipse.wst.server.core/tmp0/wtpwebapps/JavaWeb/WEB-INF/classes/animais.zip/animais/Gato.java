package animais;

public class Gato extends Animal {
	
	private int vidas;

	public Gato(float tamanho, String nome, int vidas) {
		super(tamanho, nome);
		this.vidas = vidas;
	}

	public Gato() {
		
	}
	
	public int getVidas() {
		return this.vidas;
	}

	@Override
	public String falar() {
		return "Miau";

	}

	@Override
	public String andar() {
		return getNome() + " andando...";
	}
	
	public void arranhar() {
		System.out.println("rasg");
	}

}
